package com.example.gracehopperapp.ui.theme

import androidx.compose.ui.graphics.Color

val Pink80 = Color(0xFFEFB8C8)
val Pink40 = Color(0xFF7D5260)
val DarkPink80 = Color(0xFF492532)
val OffWhite = Color(0xFFFDEFF4)
val SurfacePink = Color(0xFFFADAE5)
val TextColor = Color(0xFF3D2F34)